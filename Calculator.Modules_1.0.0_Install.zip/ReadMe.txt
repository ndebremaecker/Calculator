Calculator Devis

1- Install Modules' Packages
2- Execute Script on DNN's DB