Calculator Devis

1- Install Modules' Packages.
	1-1 Clients_1.0.0_Install
	1-2 Products_1.0.0_Install
	1-3 Devis Generator_1.0.0_Install
2- Execute script.sql on DNN's DB